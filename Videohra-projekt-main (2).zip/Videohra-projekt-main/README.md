Kolize 👍
bro smazal všechen jinej text 🥀
nešlo mi jinak poslat ty složky

btw byl bych pro odstranění diagonálního pohybu, vytváří strašně moc problémů s kolizí (které se mi nechce spravovat)
Před několika měsíci jsem dělal podobnou hru ve Scratchi, mělo to podobný problém stím, že postava se zasekne ve zdi a program se ji szaží dostat ven, jenom špatným směrem. 

Přidal jsem sprite 'thug', kterému se dá vyhmezit cesta pro pohyb. Mělo by to být ve větvi 'větev lol'. Nevím, jak u toho udělat kolizi s hráčem
